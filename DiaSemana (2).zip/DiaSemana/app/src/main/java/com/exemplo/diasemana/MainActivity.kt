package com.exemplo.diasemana

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.time.DateTimeException
import java.time.DayOfWeek
import java.time.LocalDate

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etDia = findViewById<EditText>(R.id.etDia)
        val etMes = findViewById<EditText>(R.id.etMes)
        val etAno = findViewById<EditText>(R.id.etAno)
        val tv = findViewById<TextView>(R.id.tvResultado)

        findViewById<Button>(R.id.btnDescobrir).setOnClickListener {
            val dia = etDia.text.toString().toIntOrNull()
            val mes = etMes.text.toString().toIntOrNull()
            val ano = etAno.text.toString().toIntOrNull()

            if (dia == null || mes == null || ano == null) {
                tv.text = "Preencha dia, mês e ano."
                return@setOnClickListener
            }
            if (ano < 1901) {
                tv.text = "O ano deve ser 1901 ou posterior."
                return@setOnClickListener
            }
            try {
                val data = LocalDate.of(ano, mes, dia)
                if (data.isAfter(LocalDate.now())) {
                    tv.text = "Essa data ainda não chegou!"
                    return@setOnClickListener
                }
                tv.text = "Você nasceu em uma ${nomeDia(data.dayOfWeek)}!"
                    .replace("uma Domingo", "um Domingo")
                    .replace("uma Sábado", "um Sábado")
            } catch (e: DateTimeException) {
                tv.text = "Data inválida. Confira dia, mês e ano."
            }
        }
    }

    private fun nomeDia(d: DayOfWeek) = when (d) {
        DayOfWeek.MONDAY -> "Segunda-feira"
        DayOfWeek.TUESDAY -> "Terça-feira"
        DayOfWeek.WEDNESDAY -> "Quarta-feira"
        DayOfWeek.THURSDAY -> "Quinta-feira"
        DayOfWeek.FRIDAY -> "Sexta-feira"
        DayOfWeek.SATURDAY -> "Sábado"
        DayOfWeek.SUNDAY -> "Domingo"
    }
}
